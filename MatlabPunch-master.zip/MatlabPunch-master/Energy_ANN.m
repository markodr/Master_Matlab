clc
clear all
close all
 
    % Ucitaj Udrarac 1
[Energija_1,Signal_1]=energije(1,'Signali/p1_',11);
    % Ucitaj Udrarac 2
[Energija_2,Signal_2]=energije(2,'Signali/p2_',11);
    % Ucitaj Udrarac 3
[Energija_3,Signal_3]=energije(3,'Signali/p3_',11);
    % Ucitaj Udrarac 4
[Energija_4,Signal_4]=energije(4,'Signali/p4_',11);
    % Ucitaj Udrarac 5
%[Energija_5,Signal_5]=energije(5,'Signali/p5_',11);
    % Ucitaj Udrarac 6
[Energija_6,Signal_6]=energije(6,'Signali/p6_',11);
    % Ucitaj Udrarac 7
[Energija_7,Signal_7]=energije(7,'Signali/p7_',11);
    % Ucitaj Udrarac 8
[Energija_8,Signal_8]=energije(8,'Signali/p8_',11);
    % Ucitaj Udrarac 9
[Energija_9,Signal_9]=energije(9,'Signali/p9_',11);


% Iz ucitanih fajlova pravim TRAIN i TEST set, isti set za obe mreza
close all;

% Uzimamo svaki treci i osmi udarac za test set
train_set=[ 1,2,3,4,5,6,7,8,9,10];
test_set= [ 11]; % ,7,8,9,10,11

% OBUKA =============================================================
obuka_ulaz=[Energija_1(1:4,train_set),Energija_2(1:4,train_set)...
           ,Energija_3(1:4,train_set),Energija_4(1:4,train_set)...
           ,Energija_6(1:4,train_set)...
           ,Energija_7(1:4,train_set),Energija_8(1:4,train_set)...
           ,Energija_9(1:4,train_set)];
obuka_izlaz=[Energija_1(5,train_set),Energija_2(5,train_set)...
            ,Energija_3(5,train_set),Energija_4(5,train_set)...
            ,Energija_6(5,train_set)...
            ,Energija_7(5,train_set),Energija_8(5,train_set)...
            ,Energija_9(5,train_set)];
 
% TEST =============================================================  
test_ulaz=[Energija_1(1:4,test_set),Energija_2(1:4,test_set)...
          ,Energija_3(1:4,test_set),Energija_4(1:4,test_set)...
          ,Energija_6(1:4,test_set)...
          ,Energija_7(1:4,test_set),Energija_8(1:4,test_set)...
          ,Energija_9(1:4,test_set)];  
test_izlaz=[Energija_1(5,test_set),Energija_2(5,test_set)...
           ,Energija_3(5,test_set),Energija_4(5,test_set)...
           ,Energija_6(5,test_set)...
           ,Energija_7(5,test_set),Energija_8(5,test_set)...
           ,Energija_9(5,test_set)];  
        
       

clear Signal_1; clear Signal_2; clear Signal_3;
clear Signal_4; clear Signal_5; clear Signal_6;
clear Signal_7; clear Signal_8; clear Signal_9;
clear train_set; clear test_set;
  
%%

 ULAZ=[Energija_1(1:4,1:3),Energija_2(1:4,1:3)...
      ,Energija_3(1:4,1:3),Energija_4(1:4,1:3)...
      ,Energija_6(1:4,1:3),Energija_7(1:4,1:3)...
      ,Energija_8(1:4,1:3),Energija_9(1:4,1:3)];

izlazx=[Energija_1(5,1:3),Energija_2(5,1:3)...
       ,Energija_3(5,1:3),Energija_4(5,1:3)...
       ,Energija_6(5,1:3),Energija_7(5,1:3)...
       ,Energija_8(5,1:3),Energija_9(5,1:3)];     
%%
ULAZ=[obuka_ulaz];
IZLAZ=[];
for i=1:length(obuka_izlaz)
    tmp=de2bi(obuka_izlaz(i),4);
    IZLAZ(:,i)=tmp';
end



SMOR=[ULAZ;IZLAZ];

x=ULAZ;
t=IZLAZ;
net = patternnet([80,40]);
net = train(net,x,t);
%view(net)
y = net(x);
perf = perform(net,t,y);
classes = vec2ind(y);
%plotconfusion(IZLAZ,ULAZ);
%nnstart

% https://www.mathworks.com/help/nnet/gs/classify-patterns-with-a-neural-network.html
% https://www.mathworks.com/help/nnet/ref/softmax.html
% https://www.mathworks.com/help/nnet/examples/wine-classification.html
% https://www.mathworks.com/help/nnet/ug/train-and-apply-multilayer-neural-networks.html
